const DappKart = artifacts.require('DappKart')
const DappToken = artifacts.require('DappToken')
const Dispute = artifacts.require('DisputeContract')
let DappTokenInstance, DisputeInstance

const admins = ['0x9eF3572cfb87267e29B65ff33f9649CA86ccDc98',
	'0x996a03488e35c0b97D86554B4777297Ea49Cf05B',
	'0x2B4f1b7d2eE22609633ce5Dd52994Fb5A75e13FB']

module.exports = async function (deployer) {
	deployer.deploy(DappToken).then(instance => {
		DappTokenInstance = instance
		return deployer.deploy(Dispute,
			admins,
			DappTokenInstance.address)
	})
		.then(instance => {
			DisputeInstance = instance
			return deployer.deploy(DappKart, DappTokenInstance.address, DisputeInstance.address)
		})
}

