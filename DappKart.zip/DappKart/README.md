## Project Name
**DAPPKART** - A Decentralized Ecommerce platform using Ethereum and ERC20 Token
			
## How to Run the application
1. Go to 'dpk-eth' directory and migrate the contract in the test network
    **The array of admins' addresses should be modified accordingly in mingrations (dpk.js file)**
    **Update truffle-config file according to your seed phase and ropsten node**
    <command> : cd dpk-eth
    <command> : truffle deploy --network ropsten
2. Download Redis and start the redis server using the command:
    <command> : sudo apt install redis-server
    <command> : redis-server --protected-mode no
3. Go to 'dpk-db' directory and update Redis host and port in .env file
3. Go to home directory and run the command:
    <command> : docker-compose up
4. Go to 'dpk-ui' directory and run the front-end of the application 
    <command> : cd dpk-ui
    <command> : npm install
    <command> : ng serve
5. Go to the url and run the application
    <url>   :   http://localhost:4200