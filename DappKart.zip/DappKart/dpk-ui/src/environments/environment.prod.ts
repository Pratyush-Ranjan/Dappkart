export const environment = {
  production: true,
  imgurl: 'http://0.0.0.0:3000/'
}
