export interface Web3Model {
  account: string
  network: string
  dpk: any
  token: any
  dispute: any
}
