import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-router',
  templateUrl: './seller-router.component.html',
  styleUrls: ['./seller-router.component.scss']
})
export class SellerRouterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
