import { async } from '@angular/core/testing'
import { Component, OnInit } from '@angular/core'
import { DpkService } from 'src/app/Services/dpk/dpk.service'
import { Web3Service } from 'src/app/Services/Web3/web3.service'
import { UserBalanceModel, TokenModel } from 'src/app/Models/dpk.model'
import { Web3Model } from 'src/app/Models/web3.model'
import { Router } from '@angular/router'

@Component( {
  selector: 'app-seller',
  templateUrl: './seller.component.html',
  styleUrls: [ './seller.component.scss' ],
} )
export class SellerComponent implements OnInit {
  userBalance: UserBalanceModel = {
    etherBal: null,
    tokenBal: null,
  }
  account: string
  dpk: any
  token: any
  constructor (
    private dapp: DpkService,
    private web3service: Web3Service,
    private route: Router
  ) { }

  ngOnInit() {
    this.web3service.web3login()
    this.web3service.Web3Details$.subscribe( async ( data: Web3Model ) => {
      this.account = data.account
      this.dpk = data.dpk
      this.token = data.token
    } )
    this.load()
  }
  load = async () => {
    const userDetails = await this.dpk.userDetails().call( { from: this.account } )
    sessionStorage.setItem( 'name', await this.web3service.fromBytes( userDetails.userName ) )
    const dpkDetails: TokenModel = await this.token
      .dpkDetail()
      .call( { from: this.account } )
    this.userBalance = {
      etherBal: await this.dapp.getBalance( this.account ),
      tokenBal:
        ( await this.token.balance( this.account ).call( { from: this.account } ) ) /
        10 ** dpkDetails.tokenDecimals,
    }
  }
  logOut = async () => {
    sessionStorage.clear()
    this.route.navigateByUrl( '/' )
  }
}
