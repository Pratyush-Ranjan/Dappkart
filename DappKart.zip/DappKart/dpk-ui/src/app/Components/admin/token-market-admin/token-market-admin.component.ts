import { TokenModel, UserBalanceModel } from '../../../Models/dpk.model'
import { Component, OnInit } from '@angular/core'
import { SpkService } from 'src/app/Services/dpk/dpk.service'
import { Web3Service } from 'src/app/Services/Web3/web3.service'
import { Web3Model } from 'src/app/Models/web3.model'
import {
  TokenModelClass,
  UserBalanceModelClass,
} from 'src/app/Models/Class/cart.class'
import { Router } from '@angular/router'

@Component({
  selector: 'app-token-market-admin',
  templateUrl: './token-market-admin.component.html',
  styleUrls: ['./token-market-admin.component.scss'],
})
export class TokenMarketAdminComponent implements OnInit {
  buyCount: number = null
  sellCount: number = null
  account: string
  dpk: any
  token: any
  dappToken: TokenModel = new TokenModelClass()
  userBalance: UserBalanceModel = new UserBalanceModelClass()
  constructor( private dapp: SpkService,
               private web3service: Web3Service,
               private route: Router ) {
  }

  ngOnInit() {
    this.web3service.Web3Details$.subscribe( async ( data: Web3Model ) => {
      this.account = data.account
      this.dpk = data.dpk
      this.token = data.token
    } )
    this.load()
  }
  load = async () => {
    const dpkDetails: TokenModel = await this.token.dpkDetail().call( { from: this.account } )
    this.userBalance = {
      etherBal: await this.dapp.getBalance( this.account ),
      tokenBal: ( await this.token.balance(this.account).call( { from: this.account } ) / ( 10 ** dpkDetails.tokenDecimals ) )
    }
    this.dappToken = {
      tokenName: dpkDetails.tokenName,
      tokenSymbol: dpkDetails.tokenSymbol,
      tokenDecimals: dpkDetails.tokenDecimals,
      dappTokenAddress: dpkDetails.dappTokenAddress,
      tokenOwner: dpkDetails.tokenOwner,
      tokenTotalSupply: ( dpkDetails.tokenTotalSupply / ( 10 ** dpkDetails.tokenDecimals ) ),
      dappTokenPrice: ( this.dapp.toEther( dpkDetails.dappTokenPrice ) * ( 10 ** dpkDetails.tokenDecimals ) ),
      etherBal: this.dapp.toEther( dpkDetails.etherBal ),
      tokenBalance: ( dpkDetails.tokenBalance / ( 10 ** dpkDetails.tokenDecimals ) )
    }
  }
  buy = async () => {
    const ethAmount = this.dapp.toWei( this.buyCount * this.dappToken.dappTokenPrice )
    const buyers = await this.dpk.purchaseToken().send( {
      from: this.account,
      gas: 177982,
      value: ethAmount
    } )
    this.load()
  }
  sell = async () => {
    const sellers = await this.dpk.sellToken( this.sellCount * 100 ).send( {
      from: this.account,
      gas: 177982
    } )
    this.load()
  }
  logOut = async () => {
    sessionStorage.clear()
    this.route.navigateByUrl('/')
  }
}
