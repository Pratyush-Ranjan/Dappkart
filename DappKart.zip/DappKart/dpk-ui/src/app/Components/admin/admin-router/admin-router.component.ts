import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-router',
  templateUrl: './admin-router.component.html',
  styleUrls: ['./admin-router.component.scss']
})
export class AdminRouterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
