import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-router',
  templateUrl: './user-router.component.html',
  styleUrls: ['./user-router.component.scss']
})
export class UserRouterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
