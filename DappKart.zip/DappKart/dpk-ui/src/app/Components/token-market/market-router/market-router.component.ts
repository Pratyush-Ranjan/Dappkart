import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-router',
  templateUrl: './market-router.component.html',
  styleUrls: ['./market-router.component.scss']
})
export class MarketRouterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
